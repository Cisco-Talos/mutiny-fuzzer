#!/bin/sh

echo zombieslartibartfasterthaneelslartibartfastenyourseatbelts | $@ -m ft -p od -n 30 | grep -q zombieslartibartfastenyourseatbelts || exit 1

