INSTALLATION

  $ tar -zxvf radamsa-0.3.tar.gz
  $ cd radamsa-0.3
  $ make
  $ sudo make install

  You can also just copy radamsa-0.3/bin/radamsa somewhere after
  building it.

  You need to get the Owl Lisp compiler in case you want to make
  changes to the actual source code, as opposed to the bundled pre-built
  C-code. This can be done with $ make get-owl.

REQUIREMENTS
  make
  a C-compiler

SUPPORTED OPERATING SYSTEMS
  Linux
  OpenBSD
  Mac OS X

  A Windows-binary may be available at
  http://code.google.com/p/ouspg/downloads/list
